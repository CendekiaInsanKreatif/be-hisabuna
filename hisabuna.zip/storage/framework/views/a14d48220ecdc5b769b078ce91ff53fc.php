<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Buku Besar</title>
</head>
<style>
</style>
<body>
    <div class="container" style="font-family: Arial, sans-serif; margin-top: 20px;">
        <h2 style="text-align: center; color: #333;">Buku Besar</h2>
        <?php $__currentLoopData = $bukuBesar; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $akun): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <h3 style="background-color: #f2f2f2; padding: 10px; border-radius: 5px;"><?php echo e($akun['akun_no']); ?> - <?php echo e($akun['akun_nama']); ?></h3>
            <table style="width: 100%; border-collapse: collapse; margin-bottom: 20px;">
                <thead>
                    <tr style="background-color: #4CAF50; color: white;">
                        <th style="padding: 8px; border: 1px solid #ddd;">Tanggal</th>
                        <th style="padding: 8px; border: 1px solid #ddd;">Debit</th>
                        <th style="padding: 8px; border: 1px solid #ddd;">Credit</th>
                        <th style="padding: 8px; border: 1px solid #ddd;">Saldo Akhir</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $akun['details']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $detail): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td style="padding: 8px; border: 1px solid #ddd;"><?php echo e($detail['jurnal_tgl']); ?></td>
                            <td style="padding: 8px; border: 1px solid #ddd;"><?php echo e(number_format($detail['debit'], 0, ',', '.')); ?></td>
                            <td style="padding: 8px; border: 1px solid #ddd;"><?php echo e(number_format($detail['credit'], 0, ',', '.')); ?></td>
                            <td style="padding: 8px; border: 1px solid #ddd;"><?php echo e(number_format($detail['saldo_akhir'], 0, ',', '.')); ?></td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
</body>
</html>
<?php /**PATH C:\NEWW\hisabuna\main\resources\views/report/buku_besar.blade.php ENDPATH**/ ?>