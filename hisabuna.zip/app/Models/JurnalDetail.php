<?php

// namespace App\Models;

// use Illuminate\Database\Eloquent\Model;

// class JurnalDetail extends Model
// {
//     protected $table = 'jurnal_detail';

//     protected $fillable = [
//         'jurnal_id',
//         'jurnal_no',
//         'jurnal_akun',
//         'debit',
//         'credit',
//     ];

//     public function jurnalHeader()
//     {
//         return $this->belongsTo(JurnalHeader::class, 'jurnal_id');
//     }
// }
