<?php

// namespace App\Models;

// use Illuminate\Database\Eloquent\Model;

// class Coa extends Model
// {
//     protected $table = 'coa';

//     protected $fillable = [
//         'akun_no',
//         'akun_nama',
//         'saldo_awal_debit',
//         'saldo_awal_credit',
//         'arus_kas',
//         'anggaran',
//     ];
// }
