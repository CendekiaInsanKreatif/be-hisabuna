<?php

// namespace Database\Factories;

// use App\Models\Coa;
// use Illuminate\Database\Eloquent\Factories\Factory;

// class CoaFactory extends Factory
// {
//     protected $model = Coa::class;

//     public function definition()
//     {
//         return [
//             'akun_no' => $this->faker->unique()->randomNumber(5),
//             'akun_nama' => $this->faker->word,
//             'saldo_awal_debit' => $this->faker->numberBetween(100, 1000),
//             'saldo_awal_credit' => $this->faker->numberBetween(100, 1000),
//             'arus_kas' => $this->faker->word,
//             'anggaran' => $this->faker->word,
//         ];
//     }
// }
