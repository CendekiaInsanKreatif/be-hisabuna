<?php

// use App\Models\JurnalHeader;
// use App\Models\JurnalDetail;
// use Illuminate\Database\Eloquent\Factories\Factory;

// class JurnalDetailFactory extends Factory
// {
//     protected $model = JurnalDetail::class;

//     public function definition()
//     {
//         $jurnalHeader = JurnalHeader::factory()->create();

//         return [
//             'jurnal_id' => $jurnalHeader->id,
//             'jurnal_no' => $this->faker->unique()->word,
//             'jurnal_akun' => $this->faker->word,
//             'debit' => $this->faker->numberBetween(100, 1000),
//             'credit' => $this->faker->numberBetween(100, 1000),
//         ];
//     }
// }
