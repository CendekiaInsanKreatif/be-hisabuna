<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Buku Besar</title>
</head>
<style>
</style>
<body>
    <div style="display: flex; align-items: center;">
        <div style="flex: 1; text-align: center; justify-content: space-between">
            <img src="<?php echo e($userInfo['company_logo']); ?>" alt="img" style="width: 100px; height: 100px">
            <h1 style="margin: 0;"><?php echo e($userInfo['company']); ?></h1>
            <h3 style="margin: 0;"><?php echo e($userInfo['company_desc']); ?></h3>
        </div>
        <br>
        <br>
        <div style="flex: 1; text-align: center; justify-content: space-between">
            <h2 style="margin: 0;">BUKU BESAR (LEDGER)</h2>
            <?php
                $awal = $data->min('jurnal_tgl');
                $akhir = $data->max('jurnal_tgl');
            ?>
            <h4 style="margin: 0;">Periode <?php echo e(date('d/m/Y', strtotime($awal))); ?> s/d <?php echo e(date('d/m/Y', strtotime($akhir))); ?></h4>
        </div>
        <div style="flex: 1; text-align: center; justify-content: space-between">
            <br>
            <br>
            <h5 style="text-align: left; color:dodgerblue;margin:0;padding:0;font-weight:bold">Akun: <?php echo e($akun->akun_no); ?>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<?php echo e($akun->akun_nama); ?></h5>
            <table style="width: 100%; border: 1px solid black;">
                <thead style="text-align: center">
                    <tr>
                        <th>Tanggal</th>
                        <th>Jurnal No</th>
                        <th>Transaksi No</th>
                        <th>Keterangan</th>
                        <th>Debit</th>
                        <th>Kredit</th>
                        <th>Saldo</th>
                    </tr>
                </thead>
                <tbody style="text-align: center">
                    <?php
                        $saldo = 0;
                    ?>
                    <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e(date('M d', strtotime($item->jurnal_tgl))); ?></td>
                            <td><?php echo e($item->jurnal_no); ?></td>
                            <td><?php echo e($item->trans_no); ?></td>
                            <td><?php echo e($item->keterangan); ?></td>
                            <td><?php echo e($item->debit); ?></td>
                            <td><?php echo e($item->credit); ?></td>
                            <?php
                                $saldo += $item->debit - $item->credit;
                            ?>
                            <td><?php echo e($saldo); ?></td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
</body>
</html>
<?php /**PATH C:\laragon\www\hisabuna\main\resources\views/report/buku_besar.blade.php ENDPATH**/ ?>