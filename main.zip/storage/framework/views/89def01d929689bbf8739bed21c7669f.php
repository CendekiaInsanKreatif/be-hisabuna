<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Laporan Laba Rugi</title>
</head>
<style>
</style>
<body>
    <div style="display: flex; align-items: center;">
        <div style="flex: 1; text-align: center; justify-content: space-between">
            <img src="<?php echo e($userInfo['company_logo']); ?>" alt="img" style="width: 100px; height: 100px">
            <h1 style="margin: 0;"><?php echo e($userInfo['company']); ?></h1>
            <h3 style="margin: 0;"><?php echo e($userInfo['company_desc']); ?></h3>
        </div>
        <br>
        <br>
        <div style="flex: 1; text-align: center; justify-content: space-between">
            <h2 style="margin: 0;">LABA RUGI</h2>
            <h4 style="margin: 0;">Periode <?php echo e(date('d/m/Y', strtotime($awal))); ?> s/d <?php echo e(date('d/m/Y', strtotime($akhir))); ?></h4>
        </div>
        <div style="flex: 1; text-align: center; justify-content: space-between">
            <br>
            <br>
            <table class="table" style="width: 100%; border: 1px solid black;">
                <thead>
                    <tr>
                        <th style="text-align: left">Keterangan</th>
                        <th>Jumlah</th>
                    </tr>
                </thead>
                <tbody style="text-align: center">
                    <?php $__currentLoopData = $data['Pendapatan']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $namaAkun => $pendapatan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php $__currentLoopData = $pendapatan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td style="text-align: left"><?php echo e($namaAkun); ?></td>
                                <td><?php echo e(number_format($item->jumlah, 2)); ?></td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php $__currentLoopData = $data['Beban']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $namaAkun => $beban): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php $__currentLoopData = $beban; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td style="text-align: left"><?php echo e($namaAkun); ?></td>
                                <td><?php echo e(number_format($item->jumlah, 2)); ?></td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
</body>
</html>
<?php /**PATH C:\laragon\www\hisabuna\main\resources\views/report/laba_rugi.blade.php ENDPATH**/ ?>