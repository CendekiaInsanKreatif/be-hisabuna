<?php

// namespace Database\Factories;

// use App\Models\JurnalHeader;
// use Illuminate\Database\Eloquent\Factories\Factory;

// class JurnalHeaderFactory extends Factory
// {
//     protected $model = JurnalHeader::class;

//     public function definition()
//     {
//         return [
//             'trans_no' => $this->faker->unique()->word,
//             'jurnal_tgl' => $this->faker->dateTimeThisMonth(),
//             'voucher' => $this->faker->word,
//             'keterangan' => $this->faker->sentence,
//         ];
//     }
// }
