<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>
    <title>Document</title>
    <style>
        /* td{
            padding: 0.5rem 1.5rem;
        }

        tbody td{
            font-size: 12px;
        }

        tfoot td{
            font-size: 1rem;
            font-weight: bold;
        }

        div {
            padding: 0 2rem 1rem;
            display: flex;
            text-align: center;
        }

        @media print {
          thead {
            display: table-row-group
          }
        } */
    </style>
</head>
<body>
    <div style="display: flex; align-items: center;">
        <div style="flex: 1; text-align: center; justify-content: space-between">
            <img src="{{ $userInfo['company_logo'] }}" alt="img" style="width: 100px; height: 100px">
            <h1 style="margin: 0;">{{ $userInfo['company'] }}</h1>
            <h3 style="margin: 0;">{{ $userInfo['company_desc'] }}</h3>
        </div>
        <br>
        <div style="flex: 1; text-align: center; justify-content: flex-start">
            <h2 style="margin: 0; text-decoration: underline">
                {{ ($data[0]->voucher == 'RV') ? 'JURNAL KAS MASUK' : (($data[0]->voucher == 'PV') ? 'JURNAL KAS KELUAR' : 'JURNAL UMUM') }}
            </h2>
            <h4 style="margin: 0;">
                {{ ($data[0]->voucher == 'RV') ? 'RECEIVE VOUCHER' : (($data[0]->voucher == 'PV') ? 'PAYMENT VOUCHER' : 'JURNAL VOUCHER') }}
            </h4>
        </div>
    </div>
    <div style="display: flex; justify-content: space-between;">
        <table style="width: 100%;">
            <thead style="text-align: start;">
                <tr>
                    <th style="width: 48%; border: 1px solid black;">Keterangan Transaksi</th>
                    <th style="width: 38%; font-weight:normal; text-align: left;">Tanggal&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;: {{ date("d/m/Y", strtotime($data[0]->jurnal_tgl)) }}</th>
                </tr>
            </thead>
            <tbody>
                <tr>
                    <td style="text-align: center; border: 1px solid black; border-bottom: none;">{{ $data[0]->keterangan }}</td>
                    <td>Nomor Jurnal&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;: {{ $data[0]->voucher.'-'.$data[0]->trans_no }}</td>
                </tr>
                <tr>
                    <td style="text-align: center; border: 1px solid black; border-top: none;"></td>
                    <td>Nomor Transaksi : {{ $data[0]->trans_no }}</td>
                </tr>
            </tbody>
        </table>
    </div>
    <br>
    <div style="display: flex; justify-content: space-between;">
        <table style="border: 1px solid black; width: 100%">
            <thead style="border: 1px solid black">
                <tr>
                    <th>Nomor Akun</th>
                    <th>Nama Akun</th>
                    <th>Subtotal</th>
                    <th>Debit</th>
                    <th>Kredit</th>
                </tr>
            </thead>
            <tbody style="text-align: center">
                @php
                    $totalDebit = 0;
                    $totalKredit = 0;
                @endphp
                @foreach($data[0]->detail as $detail)
                @php
                    $subtotal = 0;
                @endphp
                    <tr>
                        <td style="font-weight:bold; text-align:left">{{ $detail['akun_no'] }}</td>
                        <td style="font-weight:bold; text-align:left">{{ $detail['akun_nama'] }}</td>
                        <td style="font-weight:bold; text-align:left"></td>
                        <td style="font-weight:bold; text-align:center">{{ $detail['child'][0]->debit ? number_format($detail['subtotal']) : 0 }}</td>
                        <td style="font-weight:bold; text-align:center">{{ $detail['child'][0]->credit ? number_format($detail['subtotal']) : 0 }}</td>
                    </tr>
                    @foreach($detail['child'] as $child)
                        <tr>
                            <td style="text-align: left">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;{{ $child->akun_no }}</td>
                            <td style="text-align: left;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;{{ $child->akun_nama }}</td>
                            <td>{{ $child->credit ? number_format($child->credit) : number_format($child->debit) }}</td>
                            <td></td>
                            <td></td>
                        </tr>
                        @php
                            $subtotal += $child->debit ?? 0;
                            $subtotal -= $child->credit ?? 0;

                            $totalDebit += $child->debit ?? 0;
                            $totalKredit += $child->credit ?? 0;
                        @endphp
                    @endforeach
                @endforeach
                <tr>
                    <td colspan="5">&nbsp;</td>
                </tr>
                <tr style="border-top: 1px solid black">
                    <td colspan="2"></td>
                    <td>Total</td>
                    <td>{{ number_format($totalDebit) }}</td>
                    <td>{{ number_format($totalKredit) }}</td>
                </tr>
            </tbody>
        </table>
    </div>
</body>
</html>
