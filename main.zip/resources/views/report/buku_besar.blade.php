<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Buku Besar</title>
</head>
<style>
</style>
<body>
    <div style="display: flex; align-items: center;">
        <div style="flex: 1; text-align: center; justify-content: space-between">
            <img src="{{ $userInfo['company_logo'] }}" alt="img" style="width: 100px; height: 100px">
            <h1 style="margin: 0;">{{ $userInfo['company'] }}</h1>
            <h3 style="margin: 0;">{{ $userInfo['company_desc'] }}</h3>
        </div>
        <br>
        <br>
        <div style="flex: 1; text-align: center; justify-content: space-between">
            <h2 style="margin: 0;">BUKU BESAR (LEDGER)</h2>
            @php
                $awal = $data->min('jurnal_tgl');
                $akhir = $data->max('jurnal_tgl');
            @endphp
            <h4 style="margin: 0;">Periode {{ date('d/m/Y', strtotime($awal)) }} s/d {{ date('d/m/Y', strtotime($akhir)) }}</h4>
        </div>
        <div style="flex: 1; text-align: center; justify-content: space-between">
            <br>
            <br>
            <h5 style="text-align: left; color:dodgerblue;margin:0;padding:0;font-weight:bold">Akun: {{$akun->akun_no}}&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;{{ $akun->akun_nama }}</h5>
            <table style="width: 100%; border: 1px solid black;">
                <thead style="text-align: center">
                    <tr>
                        <th>Tanggal</th>
                        <th>Jurnal No</th>
                        <th>Transaksi No</th>
                        <th>Keterangan</th>
                        <th>Debit</th>
                        <th>Kredit</th>
                        <th>Saldo</th>
                    </tr>
                </thead>
                <tbody style="text-align: center">
                    @php
                        $saldo = 0;
                    @endphp
                    @foreach($data as $item)
                        <tr>
                            <td>{{ date('M d', strtotime($item->jurnal_tgl)) }}</td>
                            <td>{{ $item->jurnal_no }}</td>
                            <td>{{ $item->trans_no }}</td>
                            <td>{{ $item->keterangan }}</td>
                            <td>{{ $item->debit }}</td>
                            <td>{{ $item->credit }}</td>
                            @php
                                $saldo += $item->debit - $item->credit;
                            @endphp
                            <td>{{ $saldo }}</td>
                        </tr>
                    @endforeach
                </tbody>
            </table>
        </div>
    </div>
</body>
</html>
