<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Daftar Jurnal</title>
</head>
<style>
</style>
<body>
    <div style="display: flex; align-items: center;">
        <div style="flex: 1; text-align: center; justify-content: space-between">
            <img src="{{ $userInfo['company_logo'] }}" alt="img" style="width: 100px; height: 100px">
            <h1 style="margin: 0;">{{ $userInfo['company'] }}</h1>
            <h3 style="margin: 0;">{{ $userInfo['company_desc'] }}</h3>
        </div>
        <br>
        <br>
        <div style="flex: 1; text-align: center; justify-content: space-between">
            <h1 style="margin: 0;">DAFTAR JURNAL</h1>
            <h3 style="margin: 0;">Periode Semua</h3>
        </div>
        <div style="flex: 1; text-align: center; justify-content: space-between">
            <table style="width: 100%; border: 1px solid black;">
                <thead>
                    <tr>
                        <th>No</th>
                        <th colspan="2">Transaksi</th>
                        <th>Keterangan Jurnal</th>
                        <th colspan="3">Nomor Jurnal</th>
                        <th>Jumlah</th>
                    </tr>
                    <tr>
                        <th></th>
                        <th>Nomor</th>
                        <th>Tanggal</th>
                        <th></th>
                        <th>RV</th>
                        <th>PV</th>
                        <th>JV</th>
                        <th></th>
                    </tr>
                </thead>
                <tbody style="text-align: center; border: 1px solid black;">
                    @php 
                        $total = 0;
                    @endphp

                    @foreach ($data as $x => $y)
                    @php
                        $color = ''; // Default color
                        switch ($y->voucher) {
                            case 'RV':
                                $color = 'background-color: pink;';
                                break;
                            case 'PV':
                                $color = 'background-color: white;';
                                break;
                            case 'JV':
                                $color = 'background-color: yellow;';
                                break;
                            default:
                                $color = '';
                                break;
                        }
                        $total += $y->subtotal;
                    @endphp
                        <tr style="border: 1px solid black; {{ $color }}">
                            <td>{{$x+1}}</td>
                            <td>{{$x+1}}</td>
                            <td>{{ date('d/m/Y', strtotime($y->jurnal_tgl)) }}</td>
                            <td>{{$y->keterangan}}</td>
                            <td>{{ ($y->voucher == 'RV') ? $y->trans_no : '' }}</td>
                            <td>{{ ($y->voucher == 'PV') ? $y->trans_no : '' }}</td>
                            <td>{{ ($y->voucher == 'JV') ? $y->trans_no : '' }}</td>
                            <td>{{ $y->subtotal }}</td>
                        </tr>
                    @endforeach
                </tbody>
                <tfoot>
                    <tr>
                        <td colspan="7">Total</td>
                        <td><?=  $total ?></td>
                    </tr>
                </tfoot>
            </table>
        </div>
    </div>
</body>
</html>
