<?php

// namespace App\Models;

// use Illuminate\Database\Eloquent\Model;

// class JurnalHeader extends Model
// {
//     protected $table = 'jurnal_header';

//     protected $fillable = [
//         'trans_no',
//         'jurnal_tgl',
//         'voucher',
//         'keterangan',
//     ];

//     public function jurnalDetails()
//     {
//         return $this->hasMany(JurnalDetail::class, 'jurnal_id');
//     }
// }
