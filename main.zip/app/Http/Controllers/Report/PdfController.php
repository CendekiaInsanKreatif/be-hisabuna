<?php

namespace App\Http\Controllers\Report;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Barryvdh\DomPDF\Facade\Pdf;
use Illuminate\Support\Facades\Auth;

class PdfController extends Controller
{
    public function jurnalReport(){
        $data = DB('jurnal_headers')->select(['id','jurnal_tgl','voucher','keterangan','company_id','lampiran','trans_no','subtotal'])->orderBy('jurnal_tgl')->orderBy('trans_no')->get();
        $data = $data->toArray();
        $user = Auth::user();
        $userInfo = userInfo();
        $pdf = Pdf::loadView('report.daftar_jurnal', compact('userInfo','data'));
        return $pdf->download('daftar_'.'jurnal_'.Auth::user()->company.date('Y-m-d').'.pdf');
    }

    public function bukuBesar(Request $request){
        $data = DB('jurnal_headers')->select([
            'jurnal_headers.jurnal_tgl',
            'jurnal_headers.trans_no',
            'jurnal_details.jurnal_no',
            'jurnal_details.keterangan',
            'jurnal_details.debit',
            'jurnal_details.credit',
        ])->leftJoin('jurnal_details','jurnal_headers.id','=','jurnal_details.jurnal_id')
        ->where(['jurnal_details.jurnal_akun' => $request->akun_no])->orderBy('jurnal_tgl')->orderBy('trans_no')->get();
        $akun = DB('coas')->select(['akun_no','akun_nama'])->where(['akun_no' => $request->akun_no])->first();
        $userInfo = userInfo();
        $pdf = Pdf::loadView('report.buku_besar', compact('data','userInfo','akun'));
        return $pdf->download('buku_'.'besar_'.$request->akun_no.'_'.Auth::user()->company.'_'.date('Y-m-d').'.pdf');
    }

    public function labaRugi(Request $request){
        $akunPendapatan = DB('coas')->where('akun_no', 'like', '4%')->get();
        $akunBeban = DB('coas')->where('akun_no', 'like', '5%')->get();
        $awal = $request->tgl_awal;
        $akhir = $request->tgl_akhir;
        $data = [];

        foreach ($akunPendapatan as $akun) {
            $pendapatan = DB('jurnal_details')
                ->join('jurnal_headers', 'jurnal_details.jurnal_id', '=', 'jurnal_headers.id')
                ->where('jurnal_headers.jurnal_tgl', '>=', $awal)
                ->where('jurnal_headers.jurnal_tgl', '<=', $akhir)
                ->selectRaw('jurnal_headers.keterangan, SUM(jurnal_details.credit) - SUM(jurnal_details.debit) as jumlah')
                ->groupBy('jurnal_headers.keterangan')
                ->get();

            $data['Pendapatan'][$akun->akun_nama] = $pendapatan;
        }

        foreach ($akunBeban as $akun) {
            $beban = DB('jurnal_details')
                ->join('jurnal_headers', 'jurnal_details.jurnal_id', '=', 'jurnal_headers.id')
                ->where('jurnal_headers.jurnal_tgl', '>=', $awal)
                ->where('jurnal_headers.jurnal_tgl', '<=', $akhir)
                ->selectRaw('jurnal_headers.keterangan, SUM(jurnal_details.debit) - SUM(jurnal_details.credit) as jumlah')
                ->groupBy('jurnal_headers.keterangan')
                ->get();

            $data['Beban'][$akun->akun_nama] = $beban;
        }

        $userInfo = userInfo();

        $pdf = Pdf::loadView('report.laba_rugi', compact('data', 'userInfo','awal','akhir'));
        return $pdf->download('laba_rugi_'.Auth::user()->company.'_'.date('Y-m-d').'.pdf');
    }

    public function neracaPerbandingan(Request $request){
        $awal = $request->tgl_awal;
        $akhir = $request->tgl_akhir;
        $saldoAwalAset = DB('jurnal_details')
            ->join('jurnal_headers', 'jurnal_details.jurnal_id', '=', 'jurnal_headers.id')
            ->where('jurnal_headers.jurnal_tgl', '<', $request->tgl_awal)
            ->whereIn('jurnal_details.jurnal_akun', function($query){
                $query->select('akun_no')->from('coas')->where('akun_no', 'like', '1%');
            })
            ->selectRaw('SUM(jurnal_details.debit) - SUM(jurnal_details.credit) as saldo_awal')
            ->first();

        $saldoAwalKewajibanDanModal = DB('jurnal_details')
            ->join('jurnal_headers', 'jurnal_details.jurnal_id', '=', 'jurnal_headers.id')
            ->where('jurnal_headers.jurnal_tgl', '<', $request->tgl_awal)
            ->whereIn('jurnal_details.jurnal_akun', function($query){
                $query->select('akun_no')->from('coas')->where('akun_no', 'like', '2%')
                      ->orWhere('akun_no', 'like', '3%');
            })
            ->selectRaw('SUM(jurnal_details.credit) - SUM(jurnal_details.debit) as saldo_awal')
            ->first();

        $periodeAset = DB('jurnal_details')
            ->join('jurnal_headers', 'jurnal_details.jurnal_id', '=', 'jurnal_headers.id')
            ->whereBetween('jurnal_headers.jurnal_tgl', [$request->tgl_awal, $request->tgl_akhir])
            ->whereIn('jurnal_details.jurnal_akun', function($query){
                $query->select('akun_no')->from('coas')->where('akun_no', 'like', '1%');
            })
            ->selectRaw('SUM(jurnal_details.debit) - SUM(jurnal_details.credit) as periode')
            ->first();

        $periodeKewajibanDanModal = DB('jurnal_details')
            ->join('jurnal_headers', 'jurnal_details.jurnal_id', '=', 'jurnal_headers.id')
            ->whereBetween('jurnal_headers.jurnal_tgl', [$request->tgl_awal, $request->tgl_akhir])
            ->whereIn('jurnal_details.jurnal_akun', function($query){
                $query->select('akun_no')->from('coas')->where('akun_no', 'like', '2%')
                      ->orWhere('akun_no', 'like', '3%');
            })
            ->selectRaw('SUM(jurnal_details.credit) - SUM(jurnal_details.debit) as periode')
            ->first();
        $data = [
            'SaldoAwal' => [
                'Aset' => $saldoAwalAset->saldo_awal,
                'KewajibanDanModal' => $saldoAwalKewajibanDanModal->saldo_awal,
            ],
            'Periode' => [
                'Aset' => $periodeAset->periode,
                'KewajibanDanModal' => $periodeKewajibanDanModal->periode,
            ]
        ];

        $userInfo = userInfo();
        $pdf = Pdf::loadView('report.neraca_perbandingan', compact('data', 'userInfo', 'request','awal','akhir'));
        return $pdf->download('neraca_perbandingan_'.Auth::user()->company.'_'.date('Y-m-d').'.pdf');
    }
}
